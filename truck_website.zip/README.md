# 🚛 TruckHub Website

Simple truck-themed website project for GitHub.

## Features
- Responsive layout
- Hero section with background image
- Truck gallery
- Simple JavaScript interaction

## How to Run
Just open `index.html` in your browser.

## Author
Created for GitHub project practice.
