function showMessage() {
  alert("Welcome to TruckHub! 🚛");
}
